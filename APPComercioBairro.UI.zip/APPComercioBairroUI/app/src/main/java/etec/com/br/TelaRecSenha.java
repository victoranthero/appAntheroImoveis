package etec.com.br;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class TelaRecSenha extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recusenha);
    }

    public void recuperarSenha(View v){

        EditText email = (EditText)findViewById(R.id.idEmailRecuperacao);

        if (email.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(),"Email Invalido.", Toast.LENGTH_SHORT).show();
        }

        else if (email.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Digite um E-mail.", Toast.LENGTH_SHORT).show();
            finish();

        } else {
            Toast.makeText(getApplicationContext(),"E-mail de recuperação enviado!", Toast.LENGTH_LONG).show();
            Intent abrir = new Intent(this, TelaLogin.class);
            startActivity(abrir);

        }
    }
}
