package etec.com.br;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class TelaCadastro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
    }

    public void cadastrar(View v){
        EditText user = (EditText)findViewById(R.id.idCadastroNome);
        EditText pass = (EditText)findViewById(R.id.idCadastraoSenha);
        EditText pass2 = (EditText)findViewById(R.id.idRepitaSenha);
        EditText email = (EditText)findViewById(R.id.idCadastroEmail);
        EditText tel = (EditText)findViewById(R.id.idCadastroFone);
        EditText nick = (EditText)findViewById(R.id.idCadastroNickname);
        EditText nasc = (EditText)findViewById(R.id.idCadastroNascimento);
        CheckBox term = (CheckBox)findViewById(R.id.idCadastroTermos);

        if(user.getText().toString().isEmpty() ||
                email.getText().toString().isEmpty() ||
                tel.getText().toString().isEmpty() ||
                nick.getText().toString().isEmpty() ||
                pass2.getText().toString().isEmpty() ||
                pass.getText().toString().isEmpty()||
                nasc.getText().toString().isEmpty()||
                term.getText().toString().isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Não deixe nenhum campo em branco.", Toast.LENGTH_SHORT).show();

        }else {

            Button btnCadastrar_Se = (Button) findViewById(R.id.btnCadastrar_Se);
            btnCadastrar_Se.setOnClickListener(new android.view.View.OnClickListener() {
                public void onClick(View view) {
                    Intent intent = new Intent(TelaCadastro.this, TelaLogin.class);
                    startActivity(intent);
                }

            });

            new AlertDialog.Builder(this)
                    .setTitle("Cadastro")
                    .setMessage("Cadastro Efetuado com sucesso.")
                    .setCancelable(false)
                    .setPositiveButton("Concluir", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialogInterface , int i) {
                            Intent intent = new Intent(TelaCadastro.this, TelaLogin.class);
                            startActivity(intent);

                        }
                    })
                    .show();
        }

    }
}
