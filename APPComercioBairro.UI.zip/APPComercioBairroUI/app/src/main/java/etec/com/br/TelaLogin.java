package etec.com.br;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TelaLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telalogin);
    }

    public void acessar(View view) {
        EditText user = (EditText) findViewById(R.id.idLogin);
        EditText pass = (EditText) findViewById(R.id.idSenha);

        if (user.getText().toString().equals("") && pass.getText().toString().equals("")){
            Intent abrir = new Intent(this, MainActivity.class);
            startActivity(abrir);
        } else {
            Toast toast = Toast.makeText(this, "Usuario ou Senha Incorreta", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    public void recuperar(View view){
        Intent intent = new Intent(this, TelaRecSenha.class);
        startActivity(intent);
    }

    public void cadastrar_se(View view) {

        TextView idCadastro = (TextView) findViewById(R.id.idCadastro);
        idCadastro.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(TelaLogin.this, TelaCadastro.class);
                startActivity(intent);

            }
        });

    }
}
